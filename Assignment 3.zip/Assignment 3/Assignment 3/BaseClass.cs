﻿public class BaseClass
{
    public virtual bool IsValidated()
    {
        return false;
    }
}
